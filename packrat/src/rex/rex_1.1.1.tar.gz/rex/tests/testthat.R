library(testthat)
library(rex)

test_check("rex")
